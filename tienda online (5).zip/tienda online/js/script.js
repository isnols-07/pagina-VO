
document.addEventListener('DOMContentLoaded', () => {
    const saludo = document.querySelector('.hero-content h1');
    const hora = new Date().getHours();
    
    if (hora < 12) saludo.textContent = "¡Buenos días! Bienvenidos";
    else if (hora < 19) saludo.textContent = "¡Buenas tardes! Bienvenidos";
    else saludo.textContent = "¡Buenas noches! Bienvenidos";
}); 

const btnCarrito = document.querySelector('.btn-cart');
btnCarrito.addEventListener('click', () => {
    alert('Producto añadido al carrito con éxito');
});

const inputCantidad = document.getElementById('cantidad');
let Total = document.getElementById("total");
const precioUnitario = 40; 
inputCantidad.addEventListener('change', (e) => {
    const total = "Total: $"+e.target.value * precioUnitario;
    console.log(`El total proyectado es: $${total}`);
    Total.textContent = total
});

const productos = document.querySelectorAll('.detail-image');
productos.forEach(card => {
    card.addEventListener('mouseover', () => card.style.transform = 'scale(1.25)');
    card.addEventListener('mouseout', () => card.style.transform = 'scale(1)');
});

const formulario = document.querySelector('form');
formulario.addEventListener('submit', (e) => {
    e.preventDefault();
    formulario.reset();
});

